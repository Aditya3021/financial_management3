export const SET_TAB = "SET_TAB";

export const setTabAction = (tab) => ({
  type: SET_TAB,
  payload: tab,
});
