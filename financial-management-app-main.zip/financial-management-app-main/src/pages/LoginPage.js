import React from "react";
import Login from "../components/Main/Login/Login";

const LoginPage = () => {
  return (
    <>
      <Login />
    </>
  );
};

export default LoginPage;
