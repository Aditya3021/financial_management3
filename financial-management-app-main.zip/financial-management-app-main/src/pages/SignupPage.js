import React from "react";
import SignUp from "../components/Main/SignUp/SignUp";

const SignupPage = () => {
  return (
    <>
      <SignUp />
    </>
  );
};

export default SignupPage;
